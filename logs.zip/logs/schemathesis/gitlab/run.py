import schemathesis
from hypothesis import strategies as st
from schemathesis.graphql import nodes

# 定义常用的标量生成器
def generate_gid(type_name):
    """生成符合 GitLab GID 格式的字符串，例如 gid://gitlab/{type_name}/{id}"""
    return st.integers(min_value=1, max_value=100).map(
        lambda id: f"gid://gitlab/{type_name}/{id}"
    ).map(nodes.String)

def generate_color():
    """生成颜色值，例如 #FF5733"""
    return st.from_regex(r"^#[0-9A-Fa-f]{6}$").map(nodes.String)

def generate_date():
    """生成日期值，例如 2023-10-01"""
    return st.dates().map(lambda date: date.isoformat()).map(nodes.String)

def generate_datetime():
    """生成 ISO8601 日期时间值，例如 2023-10-01T12:00:00+00:00"""
    return st.datetimes().map(lambda dt: dt.isoformat()).map(nodes.String)

def generate_bigint():
    """生成大整数，例如 9876543210123456789"""
    return st.integers(min_value=10**18, max_value=10**19).map(nodes.String)

def generate_duration():
    """生成持续时间的浮点数值"""
    return st.floats(min_value=0, max_value=1000).map(nodes.Float)

def generate_json():
    """生成 JSON 对象"""
    return st.fixed_dictionaries({"key": st.text()}).map(nodes.Object)

def generate_untrusted_regexp():
    """生成不可信正则表达式"""
    return st.from_regex(r".*[a-zA-Z].*").map(nodes.String)

# 注册自定义标量
custom_scalars = {
    "AbuseReportID": generate_gid("AbuseReport"),
    "AchievementsAchievementID": generate_gid("Achievements::Achievement"),
    "AchievementsUserAchievementID": generate_gid("Achievements::UserAchievement"),
    "AlertManagementAlertID": generate_gid("AlertManagement::Alert"),
    "AlertManagementHttpIntegrationID": generate_gid("AlertManagement::HttpIntegration"),
    "AnalyticsCycleAnalyticsStageID": generate_gid("Analytics::CycleAnalytics::Stage"),
    "AnalyticsCycleAnalyticsValueStreamID": generate_gid("Analytics::CycleAnalytics::ValueStream"),
    "AntiAbuseReportsNoteID": generate_gid("AntiAbuse::Reports::Note"),
    "AwardableID": generate_gid("Awardable"),
    "BigInt": generate_bigint(),
    "BoardID": generate_gid("Board"),
    "CiBuildID": generate_gid("Ci::Build"),
    "CiCatalogResourceID": generate_gid("Ci::Catalog::Resource"),
    "CiCatalogResourcesComponentID": generate_gid("Ci::Catalog::Resources::Component"),
    "CiCatalogResourcesVersionID": generate_gid("Ci::Catalog::Resources::Version"),
    "CiJobArtifactID": generate_gid("Ci::JobArtifact"),
    "CiPipelineID": generate_gid("Ci::Pipeline"),
    "CiPipelineScheduleVariableID": generate_gid("Ci::PipelineScheduleVariable"),
    "CiProcessableID": generate_gid("Ci::Processable"),
    "CiRunnerID": generate_gid("Ci::Runner"),
    "CiRunnerManagerID": generate_gid("Ci::RunnerManager"),
    "CiStageID": generate_gid("Ci::Stage"),
    "CiTriggerID": generate_gid("Ci::Trigger"),
    "ClustersAgentID": generate_gid("Clusters::Agent"),
    "ClustersAgentTokenID": generate_gid("Clusters::AgentToken"),
    "ClustersClusterID": generate_gid("Clusters::Cluster"),
    "Color": generate_color(),
    "ContainerRegistryProtectionRuleID": generate_gid("ContainerRegistry::Protection::Rule"),
    "ContainerRepositoryID": generate_gid("ContainerRepository"),
    "CustomEmojiID": generate_gid("CustomEmoji"),
    "CustomerRelationsContactID": generate_gid("CustomerRelations::Contact"),
    "CustomerRelationsOrganizationID": generate_gid("CustomerRelations::Organization"),
    "Date": generate_date(),
    "DependencyProxyManifestID": generate_gid("DependencyProxy::Manifest"),
    "DeployKeyID": generate_gid("DeployKey"),
    "DescriptionVersionID": generate_gid("DescriptionVersion"),
    "DesignManagementDesignAtVersionID": generate_gid("DesignManagement::DesignAtVersion"),
    "DesignManagementDesignID": generate_gid("DesignManagement::Design"),
    "DesignManagementVersionID": generate_gid("DesignManagement::Version"),
    "DiffNoteID": generate_gid("DiffNote"),
    "DiscussionID": generate_gid("Discussion"),
    "Duration": generate_duration(),
    "EmailID": generate_gid("Email"),
    "EnvironmentID": generate_gid("Environment"),
    "GitlabErrorTrackingDetailedErrorID": generate_gid("Gitlab::ErrorTracking::DetailedError"),
    "GlobalID": generate_gid("User"),
    "GroupID": generate_gid("Group"),
    "ISO8601Date": generate_date(),
    "ISO8601DateTime": generate_datetime(),
    "ImportSourceUserID": generate_gid("Import::SourceUser"),
    "IncidentManagementTimelineEventID": generate_gid("IncidentManagement::TimelineEvent"),
    "IncidentManagementTimelineEventTagID": generate_gid("IncidentManagement::TimelineEventTag"),
    "IntegrationsPrometheusID": generate_gid("Integrations::Prometheus"),
    "IssuableID": generate_gid("Issuable"),
    "IssueID": generate_gid("Issue"),
    "IssueParentID": generate_gid("IssueParent"),
    "JSON": generate_json(),
    "JobID": generate_gid("CommitStatus"),
    "LabelID": generate_gid("Label"),
    "ListID": generate_gid("List"),
    "MergeRequestID": generate_gid("MergeRequest"),
    "MergeRequestsClosingIssuesID": generate_gid("MergeRequestsClosingIssues"),
    "MilestoneID": generate_gid("Milestone"),
    "MlCandidateID": generate_gid("Ml::Candidate"),
    "MlCandidateMetadataID": generate_gid("Ml::CandidateMetadata"),
    "MlCandidateMetricID": generate_gid("Ml::CandidateMetric"),
    "MlCandidateParamID": generate_gid("Ml::CandidateParam"),
    "MlModelID": generate_gid("Ml::Model"),
    "MlModelVersionID": generate_gid("Ml::ModelVersion"),
    "NamespaceID": generate_gid("Namespace"),
    "NoteID": generate_gid("Note"),
    "NoteableID": generate_gid("Noteable"),
    "OrganizationsOrganizationID": generate_gid("Organizations::Organization"),
    "PackagesConanFileMetadatumID": generate_gid("Packages::Conan::FileMetadatum"),
    "PackagesConanMetadatumID": generate_gid("Packages::Conan::Metadatum"),
    "PackagesDependencyID": generate_gid("Packages::Dependency"),
    "PackagesDependencyLinkID": generate_gid("Packages::DependencyLink"),
    "PackagesMavenMetadatumID": generate_gid("Packages::Maven::Metadatum"),
    "PackagesNugetDependencyLinkMetadatumID": generate_gid("Packages::Nuget::DependencyLinkMetadatum"),
    "PackagesNugetMetadatumID": generate_gid("Packages::Nuget::Metadatum"),
    "PackagesPackageFileID": generate_gid("Packages::PackageFile"),
    "PackagesPackageID": generate_gid("Packages::Package"),
    "PackagesProtectionRuleID": generate_gid("Packages::Protection::Rule"),
    "PackagesPypiMetadatumID": generate_gid("Packages::Pypi::Metadatum"),
    "PackagesTerraformModuleMetadatumID": generate_gid("Packages::TerraformModule::Metadatum"),
    "PagesDeploymentID": generate_gid("PagesDeployment"),
    "ProjectID": generate_gid("Project"),
    "ProjectImportStateID": generate_gid("ProjectImportState"),
    "ProjectsBranchRuleID": generate_gid("Projects::BranchRule"),
    "ReleaseID": generate_gid("Release"),
    "ReleasesLinkID": generate_gid("Releases::Link"),
    "SnippetID": generate_gid("Snippet"),
    "SystemNoteMetadataID": generate_gid("SystemNoteMetadata"),
    "TerraformStateID": generate_gid("Terraform::State"),
    "Time": generate_datetime(),
    "TimelogID": generate_gid("Timelog"),
    "TodoID": generate_gid("Todo"),
    "TodoableID": generate_gid("Todoable"),
    "UntrustedRegexp": generate_untrusted_regexp(),
    "UploadID": generate_gid("Upload"),
    "UserID": generate_gid("User"),
    "UsersSavedReplyID": generate_gid("Users::SavedReply"),
    "WorkItemID": generate_gid("WorkItem"),
    "WorkItemsParentID": generate_gid("WorkItems::Parent"),
    "WorkItemsRelatedWorkItemLinkID": generate_gid("WorkItems::RelatedWorkItemLink"),
    "WorkItemsTypeID": generate_gid("WorkItems::Type"),
}

# 将所有标量注册到 Schemathesis
for scalar_name, strategy in custom_scalars.items():
    schemathesis.graphql.scalar(scalar_name, strategy)

# 加载 GraphQL Schema
schema = schemathesis.graphql.from_url(
    "http://192.168.119.136:9980/api/graphql",
    timeout=30
)

cassette_path = "gitlab_cassette.yaml"

@schema.parametrize()
def test_graphql(case):
    case.call_and_validate(headers={"Private-Token": "glpat-xqV3DTZBoXHQxcV94bUB"})

if __name__ == "__main__":
    import pytest
    pytest.main(["-v", __file__])
